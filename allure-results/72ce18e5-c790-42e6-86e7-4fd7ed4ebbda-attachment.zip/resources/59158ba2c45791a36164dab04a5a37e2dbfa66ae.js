// Stepper Form functionality
let currentStep = 1;

// Autocomplete functionality
const suggestions = ["Apple", "Banana", "Cherry", "Date", "Fig", "Grape", "Kiwi"];

let sessionTimeout;

// Functions for Web Workers
let worker;

function includeHTML() {
    const elements = document.querySelectorAll('[data-include]');
    const fetchPromises = Array.from(elements).map(el => {
        const file = el.getAttribute('data-include');
        return fetch(file)
            .then(response => response.text())
            .then(data => {
                el.innerHTML = data;
                if (file === 'header.html') {
                    document.querySelector('#nav-toggle').addEventListener('click', toggleSidebar);
                }
                if (file === 'sidebar.html') {
                    document.querySelector('#nav-close').addEventListener('click', toggleSidebar);
                    highlightActiveLink();
                }
            })
            .catch(err => console.error('Error including HTML:', err));
    });

    return Promise.all(fetchPromises);
}

function toggleSidebar() {
    const sidebar = document.querySelector('#sidebar');
    if (sidebar) {
        sidebar.classList.toggle('-translate-x-full');
    }
}

function toggleSection(button) {
    const section = button.nextElementSibling;
    if (section) {
        section.classList.toggle('hidden');
    }
}

function loadPage(url, event) {
    event.preventDefault();
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Page not found');
            }
            return response.text();
        })
        .then(data => {
            const main = document.querySelector('main');
            main.innerHTML = new DOMParser().parseFromString(data, 'text/html').querySelector('main').innerHTML;
            history.pushState(null, '', url);
            highlightActiveLink();
            initializeTabs();
            if (window.innerWidth < 768 && !document.querySelector('#sidebar').classList.contains('-translate-x-full')) {
                toggleSidebar();
            }
        })
        .catch(err => {
            console.error('Error loading page:', err);
            loadPage('404.html', { preventDefault: () => {} });
        });
}

function highlightActiveLink() {
    const links = document.querySelectorAll('[data-link]');
    const currentPath = location.pathname.split('/').pop();
    links.forEach(link => {
        link.classList.remove('bg-gray-200', 'font-bold');
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('bg-gray-200', 'font-bold');
            const section = link.closest('.section');
            if (section) {
                section.querySelector('div').classList.remove('hidden');
            }
        }
    });
}

function initializeTabs() {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            tab.classList.add('active');
            document.querySelector(`#${tab.dataset.target}`).classList.add('active');
        });
    });
}

function initializeLazyLoading() {
    const lazyImages = document.querySelectorAll('img.lazy');
    const lazyImageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const lazyImage = entry.target;
                lazyImage.src = lazyImage.dataset.src;
                lazyImage.classList.remove('lazy');
                lazyImageObserver.unobserve(lazyImage);
            }
        });
    });

    lazyImages.forEach(lazyImage => {
        lazyImageObserver.observe(lazyImage);
    });
}

window.addEventListener('popstate', () => {
    const url = location.pathname.substring(location.pathname.lastIndexOf('/') + 1);
    loadPage(url, { preventDefault: () => {} });
});

document.addEventListener('DOMContentLoaded', () => {
    includeHTML().then(() => {
        initializeTabs();
        initializeLazyLoading();
    });
});

// Function to show messages below buttons
function showMessage(buttonType, message) {
    document.getElementById(`${buttonType}-message`).innerText = message;
}

// Function to show messages below links
function showLinkMessage(linkType, message) {
    document.getElementById(`${linkType}-message`).innerText = message;
}

// Functions for Alerts
function showAlert() {
    alert('This is an alert!');
    showMessage('alert', 'Alert displayed');
}

function showPrompt() {
    const result = prompt('Please enter something:');
    showMessage('prompt', result ? `You entered: ${result}` : 'Prompt was cancelled');
}

function showConfirm() {
    const result = confirm('Do you confirm this action?');
    showMessage('confirm', result ? 'Confirmed' : 'Cancelled');
}

// Functions for Cookies
function setCookie(name, value, days) {
    const expires = new Date(Date.now() + days * 864e5).toUTCString();
    document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/';
    showMessage('set-cookie', 'Cookie set');
}

function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    const message = match ? `Cookie value: ${decodeURIComponent(match[2])}` : 'Cookie not found';
    showMessage('get-cookie', message);
}

// Functions for Session Storage
function setSessionStorage(key, value) {
    sessionStorage.setItem(key, value);
    showMessage('set-session-storage', 'Session storage set');
}

function getSessionStorage(key) {
    const value = sessionStorage.getItem(key);
    const message = value ? `Session storage value: ${value}` : 'Session storage not found';
    showMessage('get-session-storage', message);
}

// Functions for Local Storage
function setLocalStorage(key, value) {
    localStorage.setItem(key, value);
    showMessage('set-local-storage', 'Local storage set');
}

function getLocalStorage(key) {
    const value = localStorage.getItem(key);
    const message = value ? `Local storage value: ${value}` : 'Local storage not found';
    showMessage('get-local-storage', message);
}

// Functions for Web Storage (combined session and local)
function setWebStorage(key, value) {
    setSessionStorage(key, value);
    setLocalStorage(key, value);
    showMessage('set-web-storage', 'Web storage set');
}

function getWebStorage(key) {
    const sessionValue = sessionStorage.getItem(key);
    const localValue = localStorage.getItem(key);
    const message = `Session storage value: ${sessionValue ? sessionValue : 'not found'}, Local storage value: ${localValue ? localValue : 'not found'}`;
    showMessage('get-web-storage', message);
}

// Functions for Dynamic Content
function loadDynamicContent() {
    const content = `<p>This is dynamically loaded content.</p>`;
    document.getElementById('dynamic-content').innerHTML = content;
}

// Functions for Dynamic Loading
function startLoading() {
    const loadingContent = document.getElementById('loading-content');
    loadingContent.innerHTML = '<div class="spinner"></div>';
    setTimeout(() => {
        loadingContent.innerHTML = '<p>Loading complete!</p>';
    }, 2000);
}

// Functions for File Upload
function uploadFile() {
    const fileInput = document.getElementById('file-input');
    const uploadMessage = document.getElementById('upload-message');
    if (fileInput.files.length > 0) {
        uploadMessage.innerText = `File "${fileInput.files[0].name}" uploaded successfully.`;
    } else {
        uploadMessage.innerText = 'No file selected.';
    }
}

// Functions for File Download
function showDownloadMessage() {
    const downloadMessage = document.getElementById('download-message');
    downloadMessage.innerText = 'File download started.';
}

// Functions for Mouse Hover
document.addEventListener('DOMContentLoaded', function() {
    const hoverTarget = document.querySelector('.hover-target');
    const hoverContent = document.querySelector('.hover-content');

    if (hoverTarget && hoverContent) {
        hoverTarget.addEventListener('mouseover', () => {
            hoverContent.classList.remove('hidden');
        });

        hoverTarget.addEventListener('mouseout', () => {
            hoverContent.classList.add('hidden');
        });
    }
});

// Functions for Drag and Drop
$(function() {
    $("#draggable").draggable();
    $("#droppable").droppable({
        drop: function(event, ui) {
            $("#drop-message").text("Dropped successfully!");
        }
    });
});

// Functions for Date Picker
$(function() {
    $("#date-picker").datepicker();
});

// Functions for Time Picker
$(function() {
    $("#time-picker").timepicker();
});

// Functions for Slider Controls
$(function() {
    $("#slider").slider({
        range: "min",
        value: 50,
        min: 0,
        max: 100,
        slide: function(event, ui) {
            $("#slider-value").text("Value: " + ui.value);
        }
    });
    $("#slider-value").text("Value: 50");
});

// Functions for Color Picker
document.getElementById('color-picker').addEventListener('input', function() {
    const colorValue = document.getElementById('color-picker').value;
    document.getElementById('color-value').innerText = `Selected color: ${colorValue}`;
});

// Functions for Tool Tips
$(function() {
    $("#tool-tip-button").tooltip();
});

// Functions for Form Validation
document.getElementById('validation-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let isValid = true;
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const password = document.getElementById('password');

    if (!username.value) {
        isValid = false;
        document.getElementById('username-error').classList.remove('hidden');
    } else {
        document.getElementById('username-error').classList.add('hidden');
    }

    if (!email.value || !/\S+@\S+\.\S+/.test(email.value)) {
        isValid = false;
        document.getElementById('email-error').classList.remove('hidden');
    } else {
        document.getElementById('email-error').classList.add('hidden');
    }

    if (!password.value) {
        isValid = false;
        document.getElementById('password-error').classList.remove('hidden');
    } else {
        document.getElementById('password-error').classList.add('hidden');
    }

    if (isValid) {
        document.getElementById('validation-message').innerText = 'Form submitted successfully!';
    } else {
        document.getElementById('validation-message').innerText = '';
    }
});

// Functions for AJAX Requests
function makeAjaxRequest() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts/1', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            document.getElementById('ajax-response').innerText = `Title: ${response.title}`;
        } else {
            document.getElementById('ajax-response').innerText = 'Failed to load data';
        }
    };
    xhr.send();
}

// Functions for Geolocation
function getGeolocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                document.getElementById('geolocation').innerText = `Latitude: ${latitude}, Longitude: ${longitude}`;
            },
            (error) => {
                document.getElementById('geolocation').innerText = `Error: ${error.message}`;
            }
        );
    } else {
        document.getElementById('geolocation').innerText = 'Geolocation is not supported by this browser.';
    }
}

// Function for Dynamic URL Parameters
function updateURLParameter(param, value) {
    const url = new URL(window.location);
    url.searchParams.set(param, value);
    window.history.pushState({}, '', url);
    document.getElementById('url-params').innerText = `Current URL: ${url.href}`;
}

// Functions for Captcha
function validateCaptcha(event) {
    event.preventDefault();
    const response = grecaptcha.getResponse();
    const message = response ? 'Captcha completed successfully!' : 'Please complete the captcha.';
    document.getElementById('captcha-message').innerText = message;
}

// Functions for Third-party Integrations
function fetchThirdPartyData() {
    axios.get('https://jsonplaceholder.typicode.com/posts/1')
        .then(response => {
            const data = response.data;
            document.getElementById('api-data').innerText = `Title: ${data.title}`;
        })
        .catch(error => {
            document.getElementById('api-data').innerText = 'Failed to fetch data';
        });
}

// Functions for Browser Console Interaction
function logToConsole() {
    console.log('This is a message logged to the browser console.');
    alert('Check your browser console for the logged message.');
}

// Functions for Browser Resize
window.addEventListener('resize', function() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    document.getElementById('resize-message').innerText = `Width: ${width}px, Height: ${height}px`;
});

// Functions for Error Pages
function trigger404() {
    fetch('non-existent-page.html')
        .then(response => {
            if (!response.ok) {
                throw new Error('404 Not Found');
            }
            return response.text();
        })
        .catch(error => {
            document.getElementById('error-message').innerText = error.message;
        });
}

function trigger500() {
    fetch('https://httpstat.us/500')
        .then(response => {
            if (!response.ok) {
                throw new Error('500 Internal Server Error');
            }
            return response.text();
        })
        .catch(error => {
            document.getElementById('error-message').innerText = error.message;
        });
}

// Functions for Session Timeout Handling

function resetSession() {
    clearTimeout(sessionTimeout);
    sessionTimeout = setTimeout(() => {
        document.getElementById('session-timeout-message').innerText = 'Session expired due to inactivity.';
    }, 30000); // 30 seconds for demonstration, adjust as needed
}

document.addEventListener('DOMContentLoaded', resetSession);
document.addEventListener('mousemove', resetSession);
document.addEventListener('keypress', resetSession);

// Functions for Multi-language Support
function changeLanguage() {
    const language = document.getElementById('language-selector').value;
    const elements = document.querySelectorAll('[data-en], [data-es], [data-fr]');
    elements.forEach(el => {
        el.innerText = el.dataset[language];
    });
}

// Functions for Custom Context Menus
document.addEventListener('click', function() {
    document.getElementById('custom-context-menu').classList.add('hidden');
});

function showContextMenu(event) {
    event.preventDefault();
    const contextMenu = document.getElementById('custom-context-menu');
    contextMenu.style.top = `${event.clientY}px`;
    contextMenu.style.left = `${event.clientX}px`;
    contextMenu.classList.remove('hidden');
}

function contextMenuAction(option) {
    document.getElementById('context-menu-message').innerText = `You selected ${option}`;
    document.getElementById('custom-context-menu').classList.add('hidden');
}

document.addEventListener('DOMContentLoaded', function () {
    const parentDropdown = document.getElementById('parent-dropdown');
    if (parentDropdown) {
        parentDropdown.addEventListener('change', function () {
            const selectedValue = this.value;
            let options = '<option value="">Select an option</option>';
            if (selectedValue === 'fruit') {
                options += '<option value="apple">Apple</option><option value="banana">Banana</option>';
            } else if (selectedValue === 'vegetable') {
                options += '<option value="carrot">Carrot</option><option value="broccoli">Broccoli</option>';
            }
            document.getElementById('child-dropdown').innerHTML = options;
        });

        parentDropdown.dispatchEvent(new Event('change'));
    }
});


// Functions for WebRTC
function startWebRTC() {
    const video = document.getElementById('webrtc-video');
    navigator.mediaDevices.getUserMedia({ video: true, audio: false })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(error => {
            console.error('Error accessing media devices.', error);
        });
}

// Functions for Push Notifications
function requestNotificationPermission() {
    Notification.requestPermission().then(permission => {
        const message = permission === 'granted' ? 'Notifications enabled' : 'Notifications disabled';
        document.getElementById('notification-message').innerText = message;
    });
}

function showNotification() {
    if (Notification.permission === 'granted') {
        new Notification('Hello, this is a notification!');
    } else {
        document.getElementById('notification-message').innerText = 'Notifications are not enabled';
    }
}



function startWorker() {
    if (typeof(Worker) !== 'undefined') {
        if (typeof(worker) === 'undefined') {
            worker = new Worker('worker.js');
        }
        worker.onmessage = function(event) {
            document.getElementById('worker-result').innerText = `Worker result: ${event.data}`;
        };
        worker.postMessage('start');
    } else {
        document.getElementById('worker-result').innerText = 'Web Workers are not supported in your browser.';
    }
}

// Functions for Shadow DOM
document.addEventListener('DOMContentLoaded', () => {
    const shadowHost = document.getElementById('shadow-host');
    if (shadowHost) {
        const shadowRoot = shadowHost.attachShadow({ mode: 'open' });

        shadowRoot.innerHTML = `
            <style>
                .shadow-box {
                    padding: 20px;
                    background-color: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 4px;
                }
            </style>
            <div class="shadow-box">
                <p>This is content inside the Shadow DOM.</p>
            </div>
        `;
    }
});

// Functions for Modal Dialogs
function openModal() {
    document.getElementById('modal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('modal').classList.add('hidden');
}


// Functions for Tabs Navigation
function switchTab(tabId) {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.classList.remove('active');
    });
    
    tabContents.forEach(content => {
        content.classList.add('hidden');
    });
    
    document.getElementById(tabId).classList.add('active');
    document.getElementById(tabId + '-content').classList.remove('hidden');
}




function showSuggestions(value) {
    const suggestionsList = document.getElementById('suggestions-list');
    suggestionsList.innerHTML = '';
    if (value) {
        const filteredSuggestions = suggestions.filter(suggestion => suggestion.toLowerCase().startsWith(value.toLowerCase()));
        filteredSuggestions.forEach(suggestion => {
            const listItem = document.createElement('li');
            listItem.className = 'p-2 hover:bg-gray-200 cursor-pointer';
            listItem.innerText = suggestion;
            listItem.onclick = () => selectSuggestion(suggestion);
            suggestionsList.appendChild(listItem);
        });
        suggestionsList.classList.remove('hidden');
    } else {
        suggestionsList.classList.add('hidden');
    }
}

function selectSuggestion(suggestion) {
    const input = document.getElementById('autocomplete-input');
    input.value = suggestion;
    document.getElementById('suggestions-list').classList.add('hidden');
}

// Inline Editing functionality
function enableEditing(element) {
    const editor = document.getElementById('inline-editor');
    editor.value = element.innerText;
    editor.classList.remove('hidden');
    element.classList.add('hidden');
    editor.focus();
}

function saveChanges() {
    const editor = document.getElementById('inline-editor');
    const textElement = document.getElementById('editable-text');
    textElement.innerText = editor.value;
    textElement.classList.remove('hidden');
    editor.classList.add('hidden');
}

function handleKeydown(event) {
    if (event.key === 'Enter') {
        saveChanges();
    }
}

// Tags Input functionality
function handleTagInput(event) {
    const input = event.target;
    const value = input.value.trim();

    if (event.key === 'Enter' && value) {
        addTag(value);
        input.value = '';
    }
}

function addTag(value) {
    const tagsList = document.getElementById('tags-list');
    const tagItem = document.createElement('li');
    tagItem.className = 'tag-item bg-blue-100 text-blue-700 p-2 rounded mr-2 mt-2 cursor-pointer';
    tagItem.innerText = value;
    tagItem.onclick = () => removeTag(tagItem);
    tagsList.appendChild(tagItem);
}

function removeTag(tagItem) {
    tagItem.remove();
}



function showStep(step) {
    const steps = document.querySelectorAll('.step');
    const stepContents = document.querySelectorAll('.step-content');

    steps.forEach(s => s.classList.remove('active'));
    stepContents.forEach(sc => sc.classList.remove('active'));

    document.querySelector(`.step[data-step="${step}"]`).classList.add('active');
    document.querySelector(`.step-content[data-step="${step}"]`).classList.add('active');
}

function nextStep() {
    currentStep++;
    if (currentStep > 3) currentStep = 3; // Limit to the number of steps
    showStep(currentStep);
}

function prevStep() {
    currentStep--;
    if (currentStep < 1) currentStep = 1; // Limit to the number of steps
    showStep(currentStep);
}

function submitForm() {
    alert('Form submitted successfully!');
    // Add form submission logic here
}

// Dynamic Forms functionality
function addField() {
    const form = document.getElementById('dynamic-form');
    const formGroup = document.createElement('div');
    formGroup.className = 'form-group';
    formGroup.innerHTML = `
        <label class="block mb-2">Name:</label>
        <input type="text" class="form-input w-full" name="name[]" placeholder="Enter your name">
        <button class="btn-remove btn-red mt-2" onclick="removeField(this)">Remove</button>
    `;
    form.appendChild(formGroup);
}

function removeField(button) {
    const formGroup = button.parentElement;
    formGroup.remove();
}

// Password Strength Meter functionality
function checkPasswordStrength() {
    const password = document.getElementById('password-input').value;
    const strengthMeter = document.getElementById('password-strength-meter');
    const strengthText = document.getElementById('password-strength-text');
    const strength = getPasswordStrength(password);

    strengthMeter.style.width = strength.percent + '%';
    strengthMeter.className = `strength-meter ${strength.class}`;
    strengthText.innerText = strength.text;
}

function getPasswordStrength(password) {
    let strength = {
        percent: 0,
        text: 'Weak',
        class: 'bg-red-500'
    };

    if (password.length >= 8) {
        strength.percent += 25;
        strength.text = 'Weak';
        strength.class = 'bg-red-500';
    }
    if (/[A-Z]/.test(password)) {
        strength.percent += 25;
        strength.text = 'Fair';
        strength.class = 'bg-yellow-500';
    }
    if (/[0-9]/.test(password)) {
        strength.percent += 25;
        strength.text = 'Good';
        strength.class = 'bg-blue-500';
    }
    if (/[^A-Za-z0-9]/.test(password)) {
        strength.percent += 25;
        strength.text = 'Strong';
        strength.class = 'bg-green-500';
    }

    return strength;
}

// Multi-select Dropdown functionality
function toggleDropdown() {
    document.getElementById('dropdown-menu').classList.toggle('hidden');
    document.addEventListener('click', closeDropdownOnClickOutside, true);
}

function closeDropdownOnClickOutside(event) {
    if (!event.target.closest('.multi-select-container')) {
        document.getElementById('dropdown-menu').classList.add('hidden');
        document.removeEventListener('click', closeDropdownOnClickOutside, true);
    }
}

function toggleCheckbox(element) {
    const checkbox = element.querySelector('input[type="checkbox"]');
    checkbox.checked = !checkbox.checked;
    updateSelectedItems();
}

document.querySelectorAll('#dropdown-menu input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', updateSelectedItems);
});

function updateSelectedItems() {
    const selectedItems = Array.from(document.querySelectorAll('#dropdown-menu input[type="checkbox"]:checked')).map(checkbox => checkbox.value);
    document.getElementById('selected-items').innerText = 'Selected: ' + selectedItems.join(', ');
}


// Custom File Input functionality
function updateFileName() {
    const input = document.getElementById('customFileInput');
    const label = document.getElementById('file-input-label-text');
    const fileName = input.files.length > 0 ? input.files[0].name : 'Choose a file';
    label.innerText = fileName;
    document.getElementById('selected-file-name').innerText = 'Selected file: ' + fileName;
}
// Sortable Lists functionality
document.addEventListener('DOMContentLoaded', () => {
    const sortableList = document.getElementById('sortable-list');
    const sortableItems = sortableList.querySelectorAll('.sortable-item');

    sortableItems.forEach(item => {
        item.addEventListener('dragstart', handleDragStart);
        item.addEventListener('dragover', handleDragOver);
        item.addEventListener('drop', handleDrop);
        item.addEventListener('dragenter', handleDragEnter);
        item.addEventListener('dragleave', handleDragLeave);
        item.addEventListener('dragend', handleDragEnd);
    });
});

let draggedItem = null;

function handleDragStart(event) {
    draggedItem = event.target;
    event.target.classList.add('dragging');
    setTimeout(() => event.target.classList.add('invisible'), 0);
}

function handleDragOver(event) {
    event.preventDefault();
}

function handleDrop(event) {
    event.preventDefault();
    if (event.target.classList.contains('sortable-item') && event.target !== draggedItem) {
        const items = Array.from(draggedItem.parentNode.children);
        const draggedIndex = items.indexOf(draggedItem);
        const targetIndex = items.indexOf(event.target);
        
        if (draggedIndex < targetIndex) {
            event.target.after(draggedItem);
        } else {
            event.target.before(draggedItem);
        }
    }
    event.target.classList.remove('drag-over');
}

function handleDragEnter(event) {
    if (event.target.classList.contains('sortable-item') && event.target !== draggedItem) {
        event.target.classList.add('drag-over');
    }
}

function handleDragLeave(event) {
    event.target.classList.remove('drag-over');
}

function handleDragEnd(event) {
    event.target.classList.remove('dragging', 'invisible');
    draggedItem = null;
}

// Infinite Scroll functionality
document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('infinite-scroll-container');
    let page = 1;

    const loadMoreContent = () => {
        document.getElementById('loading').classList.remove('hidden');

        // Simulate an API call to fetch more content
        setTimeout(() => {
            for (let i = 0; i < 10; i++) {
                const item = document.createElement('div');
                item.className = 'infinite-scroll-item';
                item.textContent = `Item ${(page - 1) * 10 + i + 1}`;
                container.appendChild(item);
            }
            document.getElementById('loading').classList.add('hidden');
            page++;
        }, 1000);
    };

    const handleScroll = () => {
        const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
        if (scrollTop + clientHeight >= scrollHeight - 5) {
            loadMoreContent();
        }
    };

    window.addEventListener('scroll', handleScroll);

    // Load initial content
    loadMoreContent();
});


// Video Playback functionality
document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('video');
    const status = document.getElementById('video-status');

    video.addEventListener('play', () => {
        status.textContent = 'Video is playing';
    });

    video.addEventListener('pause', () => {
        status.textContent = 'Video is paused';
    });

    video.addEventListener('seeked', () => {
        status.textContent = `Video seeked to ${Math.floor(video.currentTime)} seconds`;
    });
});

function playVideo() {
    const video = document.getElementById('video');
    video.play();
}

function pauseVideo() {
    const video = document.getElementById('video');
    video.pause();
}

function seekVideo(seconds) {
    const video = document.getElementById('video');
    video.currentTime += seconds;
}


// Audio Playback functionality
document.addEventListener('DOMContentLoaded', () => {
    const audio = document.getElementById('audio');
    const status = document.getElementById('audio-status');

    audio.addEventListener('play', () => {
        status.textContent = 'Audio is playing';
    });

    audio.addEventListener('pause', () => {
        status.textContent = 'Audio is paused';
    });

    audio.addEventListener('seeked', () => {
        status.textContent = `Audio seeked to ${Math.floor(audio.currentTime)} seconds`;
    });
});

function playAudio() {
    const audio = document.getElementById('audio');
    audio.play();
}

function pauseAudio() {
    const audio = document.getElementById('audio');
    audio.pause();
}

function seekAudio(seconds) {
    const audio = document.getElementById('audio');
    audio.currentTime += seconds;
}

// Data Visualization functionality
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('myChart').getContext('2d');
    let chartType = 'bar';
    const chart = new Chart(ctx, {
        type: chartType,
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June'],
            datasets: [{
                label: 'Sales',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    const updateChartData = () => {
        chart.data.datasets[0].data = [10, 14, 8, 6, 9, 4];
        chart.update();
        document.getElementById('chart-status').textContent = 'Chart data updated';
    }

    const toggleChartType = () => {
        chartType = chartType === 'bar' ? 'line' : 'bar';
        chart.config.type = chartType;
        chart.update();
        document.getElementById('chart-status').textContent = `Chart type toggled to ${chartType}`;
    }

    document.getElementById('updateChartDataBtn').addEventListener('click', updateChartData);
    document.getElementById('toggleChartTypeBtn').addEventListener('click', toggleChartType);
});

// Interactive Maps functionality using Leaflet.js
document.addEventListener('DOMContentLoaded', () => {
    const mapElement = document.getElementById('map');

    if (mapElement) {
        const map = L.map('map').setView([51.505, -0.09], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
        }).addTo(map);

        const marker = L.marker([51.505, -0.09]).addTo(map)
            .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
            .openPopup();

        map.on('click', (e) => {
            L.marker([e.latlng.lat, e.latlng.lng]).addTo(map)
                .bindPopup(`Marker at ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`)
                .openPopup();
            document.getElementById('map-status').textContent = `Marker placed at ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
        });

        window.zoomIn = function() {
            map.zoomIn();
            document.getElementById('map-status').textContent = 'Zoomed in';
        }

        window.zoomOut = function() {
            map.zoomOut();
            document.getElementById('map-status').textContent = 'Zoomed out';
        }

        window.resetView = function() {
            map.setView([51.505, -0.09], 13);
            document.getElementById('map-status').textContent = 'Map view reset';
        }
    }
});

// QR Code Generation functionality
function generateQRCode() {
    const input = document.getElementById('qr-input').value;
    const qrcodeContainer = document.getElementById('qrcode');
    qrcodeContainer.innerHTML = ''; // Clear previous QR code

    if (input.trim() === "") {
        alert("Please enter some text to generate a QR code.");
        return;
    }

    const canvas = document.createElement('canvas');
    qrcodeContainer.appendChild(canvas);

    QRCode.toCanvas(canvas, input, { width: 200 }, function (error) {
        if (error) {
            console.error(error);
            alert("Error generating QR code. Please try again.");
        } else {
            document.getElementById('qrcode-status').textContent = 'QR code generated successfully.';
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/qrcode@1.4.4/build/qrcode.min.js";
    document.head.appendChild(script);
    script.onload = () => {
        console.log('QRCode library loaded successfully.');
    };
});


// Initialize TinyMCE editor
document.addEventListener('DOMContentLoaded', () => {
    tinymce.init({
        selector: '#mytextarea',
        height: 300,
        menubar: false,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic backcolor | \
            alignleft aligncenter alignright alignjustify | \
            bullist numlist outdent indent | removeformat | help'
    });
});

function getContent() {
    const content = tinymce.get('mytextarea').getContent();
    document.getElementById('editor-content').innerHTML = `<h3>HTML Content:</h3><pre>${content}</pre>`;
}
