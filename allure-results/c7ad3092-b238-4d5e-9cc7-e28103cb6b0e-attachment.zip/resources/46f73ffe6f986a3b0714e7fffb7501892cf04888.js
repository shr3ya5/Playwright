$(document).ready(function() {
		// validate signup form on keyup and submit
		$("#signupForm").validate({
			rules: {
				firstname: "required",
				lastname: "required",
				username: {
					required: true,
					minlength: 2
				},
				password: {
					required: true,
					minlength: 5
				},
				agree: "required"
			},
            errorPlacement: function(){
                return false;  // suppresses error message text
            } 
			
		});
		
        $("#signInForm").validate({
			rules: {				
				email: {
					required: true,
					email: true
				},
				password: {
					required: true,
					minlength: 5
				},
			}
		});
		
		$("#TextForm").validate({
			rules: {	
				fullname: "required",
				fullname: {
					required: true,
					minlength: 2
				},
				email: {
					required: true,
					email: true
				},
				address: {
					required: true,
					minlength: 20
				},
				password: {
					required: true,
					minlength: 5
				},
				agree: "required"
			}
		});
		
		$("#RegisterForm").validate({
			rules: {	
				firstname: "required",
				lastname: "required",
				firstname: {
					required: true,
					minlength: 2
				},
				email: {
					required: true,
					email: true
				},
				age: {
					required: true,
					minlength: 4
				},
				salary: {
					required: true,
					minlength: 20
				},
				department: {
					required: true,
					minlength: 20
				},
				agree: "required"
			}
		});
		
		$("#practiceForm").validate({
			rules: {	
				name: "required",
				name: {
					required: true,
					minlength: 2
				},
				email: {
					required: true,
					email: true
				},
				mobile: {
					required: true,
					minlength: 4
				},
				age: {
					required: true,
					minlength: 4
				},
				Gender: {
					required: true,
					minlength: 20
				},
				dob: {
					required: true,
					minlength: 10
				},
				subjects: {
					required: true,
					minlength: 4
				},
				hobbies: {
					required: true,
					minlength: 4
				},
				picture: {
					required: true,
					minlength: 4
				},
				address: {
					required: true,
					minlength: 4
				},
				state: {
					required: true,
					minlength: 4
				},
				city: {
					required: true,
					minlength: 4
				},
				agree: "required"
			}
		});
		
});
	
	
// 5 seconds delay
$(document).ready(function(e){
	$("#visibleAfter").hide();
	$('#colorChange').click(function(e){
		$('#visibleAfter').delay(5000).fadeIn();
	}); 
	
	$('.accordion-heading').click(function(){
		$(this).next().slideToggle(300);
		$('.accordion-collapse').not($(this).next()).slideUp(300);
		$(this).toggleClass('active');
		$('.accordion-heading').not($(this)).removeClass('active');
	});
	

});




// alert
function showAlert() {
	alert ("Hello world!");
}
function myDesk() {
  var txt;
  if (confirm("Press a button!")) {
    txt = "You pressed OK!";
  } else {
    txt = "You pressed Cancel!";
  }
  document.getElementById("desk").innerHTML = txt;
}
function myPromp(){
	let name = prompt("What is your name?");
}

function myMessage() {
	setTimeout(function() {
	  alert("Hello just appeared");
	}, 5000);
}

$(function () {
    $('[data-toggle="tooltip"]').tooltip()
})

// new window center stage
function PopupCenter(url, title, w, h) {
    // Fixes dual-screen position                         Most browsers      Firefox
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;
            
    width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;
            
    var left = ((width / 2) - (w / 2)) + dualScreenLeft;
    var top = ((height / 2) - (h / 2)) + dualScreenTop;
    var newWindow = window.open(url, title, 'scrollbars=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    // Puts focus on the newWindow
    if (window.focus) {
        newWindow.focus();
    }
}

// progress bar
$(function() {
  var current_progress = 0;
  var interval = setInterval(function() {
      current_progress += 10;
      $("#dynamic")
      .css("width", current_progress + "%")
      .attr("aria-valuenow", current_progress)
      .text(current_progress + "% Complete");
      if (current_progress >= 100)
          clearInterval(interval);
  }, 1000);
});


// web tables
$(document).ready(function() {
	$(".confirmdeletebtn").click(function() {
		$(this).closest('tr').remove();
	});
});



//click me